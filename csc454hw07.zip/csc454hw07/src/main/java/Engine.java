public class Engine extends CarPart{
    static String name = "Engine";

    public Engine(String n) {
        super(n);
    }

    @Override
    public String toString() {
        return "Engine";
    }
}
