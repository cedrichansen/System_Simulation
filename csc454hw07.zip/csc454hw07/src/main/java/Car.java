public class Car {

    static int numEnginesRequired = 1;
    static int numBatteriesRequired = 2;
    static int numWheelsRequired = 4;

}
