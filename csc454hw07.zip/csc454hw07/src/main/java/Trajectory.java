public class Trajectory {

    Double time;
    String[] inputs;

    Trajectory(Double realTime, String[] inputs) {
        this.time = realTime;
        this.inputs = inputs;
    }

}
