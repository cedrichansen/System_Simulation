public class Tire extends CarPart{
    static String name = "Tire";

    public Tire(String n) {
        super(n);
    }

    @Override
    public String toString() {
        return "Tire";
    }
}
