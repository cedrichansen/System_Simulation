public class Port<T>{

    T currentValue;

    public Port(T initial) {
        currentValue = initial;
    }

}